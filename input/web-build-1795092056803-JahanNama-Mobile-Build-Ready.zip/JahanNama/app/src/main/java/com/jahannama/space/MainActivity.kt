package com.jahannama.space

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SatelliteAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val Night = Color(0xFF080D20)
private val Panel = Color(0xFF131D39)
private val Gold = Color(0xFFFFC96B)
private val Cyan = Color(0xFF69D9F4)
private val Muted = Color(0xFF9EABC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 13, 32)
        window.navigationBarColor = android.graphics.Color.rgb(8, 13, 32)
        setContent { JahanNamaApp() }
    }
}

data class Planet(val name: String, val color: Color, val period: Double, val radius: Float, val size: Float, val fact: String)
private val planets = listOf(
    Planet("عطارد", Color(0xFFB9B4AA), 88.0, .16f, 4f, "نزدیک‌ترین سیاره به خورشید؛ یک سال آن فقط ۸۸ روز زمینی است."),
    Planet("زهره", Color(0xFFE6B66F), 224.7, .25f, 6f, "داغ‌ترین سیاره منظومه شمسی با جو بسیار متراکم از دی‌اکسیدکربن."),
    Planet("زمین", Color(0xFF54B8FF), 365.256, .36f, 7f, "خانه ما؛ تنها جهان شناخته‌شده‌ای که در آن حیات وجود دارد."),
    Planet("مریخ", Color(0xFFE87955), 687.0, .47f, 5.5f, "سیاره سرخ؛ کاوشگرها نشانه‌هایی از آب مایع در گذشته آن یافته‌اند."),
    Planet("مشتری", Color(0xFFD9B58E), 4332.6, .61f, 13f, "بزرگ‌ترین سیاره؛ توفان بزرگ سرخ آن صدها سال قدمت دارد."),
    Planet("زحل", Color(0xFFE8D39B), 10759.0, .75f, 11f, "به خاطر حلقه‌های گسترده و درخشانش مشهور است."),
    Planet("اورانوس", Color(0xFF83DDE0), 30687.0, .88f, 8f, "غول یخی‌ای که محور چرخشش تقریباً روی پهلو خوابیده است."),
    Planet("نپتون", Color(0xFF557BFF), 60190.0, .98f, 8f, "دورترین سیاره شناخته‌شده منظومه شمسی و جهانی بسیار سرد و بادخیز.")
)

data class Article(val category: String, val title: String, val subtitle: String, val body: String)
private val articles = listOf(
    Article("منظومه شمسی", "خورشید؛ ستاره زندگی‌بخش", "ستاره‌ای در مرکز منظومه ما", "خورشید یک ستاره از رده کوتوله زرد و کره‌ای عظیم از پلاسماست. انرژی آن در هسته و از راه همجوشی هسته‌ای تولید می‌شود. فاصله متوسط زمین تا خورشید حدود ۱۴۹٫۶ میلیون کیلومتر است؛ این فاصله را یک واحد نجومی می‌نامند."),
    Article("منظومه شمسی", "زمین و ماه", "همسایه وفادار زمین", "ماه تنها قمر طبیعی زمین است. فاصله متوسط مرکز زمین تا مرکز ماه حدود ۳۸۴٬۴۰۰ کیلومتر است. گرانش ماه در ایجاد جزر و مد اقیانوس‌ها نقش مهمی دارد و چرخه فازهای آن تقریباً ۲۹٫۵ روز طول می‌کشد."),
    Article("کهکشان‌ها", "کهکشان راه شیری", "خانه کیهانی ما", "راه شیری یک کهکشان مارپیچی میله‌ای است. منظومه شمسی در یکی از بازوهای فرعی آن، بازوی شکارچی، قرار دارد و حدود ۲۶ تا ۲۷ هزار سال نوری از مرکز کهکشان فاصله دارد. قطر دیسک ستاره‌ای آن حدود ۱۰۰ هزار سال نوری برآورد می‌شود."),
    Article("اجرام شگفت‌انگیز", "سیاه‌چاله‌ها", "گرانش در مرزهای افراطی", "سیاه‌چاله ناحیه‌ای از فضا-زمان است که گرانش آن چنان قوی است که پس از گذر از افق رویداد، حتی نور نیز نمی‌تواند از آن بگریزد. سیاه‌چاله‌ها می‌توانند از فروپاشی ستاره‌های پرجرم یا در مرکز کهکشان‌ها شکل بگیرند."),
    Article("ستاره‌ها", "تولد و مرگ ستارگان", "چرخه زندگی ستاره‌ها", "ستاره‌ها در ابرهای سرد گاز و غبار متولد می‌شوند. فشار گرانش ماده را فشرده می‌کند تا همجوشی هسته‌ای آغاز شود. سرنوشت نهایی ستاره به جرم اولیه آن بستگی دارد و می‌تواند کوتوله سفید، ستاره نوترونی یا سیاه‌چاله باشد."),
    Article("کاوش فضا", "تلسکوپ فضایی جیمز وب", "نگاهی به نخستین کهکشان‌ها", "تلسکوپ جیمز وب با رصد در فروسرخ، از میان غبار کیهانی نگاه می‌کند و نور کهکشان‌های بسیار دور را بررسی می‌کند. این رصدخانه فضایی برای مطالعه جو سیارات فراخورشیدی، شکل‌گیری ستارگان و تاریخ آغازین جهان طراحی شده است.")
)

@Composable
fun JahanNamaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selectedArticle by remember { mutableStateOf<Article?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = Cyan, background = Night, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            Column(Modifier.fillMaxSize()) {
                if (selectedArticle != null) ArticleDetail(selectedArticle!!) { selectedArticle = null }
                else {
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            0 -> HomeScreen()
                            1 -> EncyclopediaScreen { selectedArticle = it }
                            2 -> AskScreen()
                            else -> SkyScreen()
                        }
                    }
                    NavigationBar(containerColor = Color(0xFF101832), contentColor = Color.White) {
                        val items = listOf("خانه" to Icons.Default.Explore, "دانشنامه" to Icons.Default.Book, "پرسش" to Icons.Default.Search, "آسمان" to Icons.Default.SatelliteAlt)
                        items.forEachIndexed { index, pair ->
                            NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = { Icon(pair.second, null) }, label = { Text(pair.first, fontSize = 11.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Color(0xFF283454), unselectedIconColor = Muted, unselectedTextColor = Muted))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PageHeader(kicker: String, title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Text(kicker, color = Gold, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Text(title, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        if (subtitle != null) Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun HomeScreen() {
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(300_000); tick = System.currentTimeMillis() } }
    val time = remember(tick) { SimpleDateFormat("HH:mm", Locale("fa", "IR")).format(Date(tick)) }
    LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            PageHeader("به جهان‌نما خوش آمدی", "کیهان را کشف کن ✨", "دانشنامه و رصدخانه کوچک تو، همیشه همراهت")
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("منظومه شمسی", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            Text("نمای شماتیک مدار سیارات", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("به‌روزرسانی $time", color = Cyan, style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    SolarSystemGraphic(Modifier.fillMaxWidth().height(270.dp), tick)
                    Text("جایگاه‌ها و اندازه‌ها برای نمایش آموزشی ساده‌سازی شده‌اند و مقیاس واقعی ندارند.", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        item {
            Text("اعداد شگفت‌انگیز", Modifier.padding(start = 20.dp, top = 20.dp, bottom = 10.dp), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                StatCard("زمین تا خورشید", "۱۴۹٫۶", "میلیون کیلومتر", Modifier.weight(1f))
                StatCard("زمین تا ماه", "۳۸۴٬۴۰۰", "کیلومتر", Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF182849)), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Gold, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("یک حقیقت کیهانی", color = Gold, fontWeight = FontWeight.Bold)
                        Text("نور خورشید حدود ۸ دقیقه و ۲۰ ثانیه طول می‌کشد تا به زمین برسد.", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun SolarSystemGraphic(modifier: Modifier = Modifier, epoch: Long) {
    Canvas(modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val scale = size.minDimension * .46f
        val days = (epoch / 86_400_000.0)
        planets.forEachIndexed { index, p ->
            val r = scale * p.radius
            drawCircle(Color(0xFF3A496B), r, center, style = Stroke(width = 1.dp.toPx()))
            val angle = (days * 360.0 / p.period + index * 29.0) * Math.PI / 180.0
            val pos = Offset(center.x + cos(angle).toFloat() * r, center.y + sin(angle).toFloat() * r)
            if (p.name == "زحل") drawOval(p.color.copy(alpha = .8f), topLeft = Offset(pos.x - 10.dp.toPx(), pos.y - 3.dp.toPx()), size = androidx.compose.ui.geometry.Size(20.dp.toPx(), 6.dp.toPx()), style = Stroke(2.dp.toPx()))
            drawCircle(p.color, p.size.dp.toPx(), pos)
        }
        drawCircle(Color(0xFFFFB33F).copy(alpha = .2f), 20.dp.toPx(), center)
        drawCircle(Color(0xFFFFC96B), 9.dp.toPx(), center)
        drawCircle(Color.White.copy(alpha = .5f), 2.dp.toPx(), Offset(center.x - 3.dp.toPx(), center.y - 3.dp.toPx()))
    }
}

@Composable
fun StatCard(title: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(13.dp)) {
            Text(title, color = Muted, style = MaterialTheme.typography.labelSmall)
            Text(value, color = Gold, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text(unit, color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun EncyclopediaScreen(onOpen: (Article) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = articles.filter { (it.title + it.category + it.subtitle).contains(query, true) }
    Column {
        PageHeader("دانشنامه کیهان", "از زمین تا بی‌نهایت", "مطالب علمی را موضوعی بخوان و جهان را بهتر بشناس")
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), placeholder = { Text("جست‌وجو در دانشنامه") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(18.dp), colors = fieldColors())
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { article ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(article) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).background(Color(0xFF26395F), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Language, null, tint = Cyan) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(article.category, color = Gold, style = MaterialTheme.typography.labelSmall)
                            Text(article.title, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(article.subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ArticleDetail(article: Article, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("‹  بازگشت", color = Gold, modifier = Modifier.clickable { onBack() }.padding(vertical = 12.dp))
        Text(article.category, color = Cyan, fontWeight = FontWeight.Bold)
        Text(article.title, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
        Text(article.subtitle, color = Muted, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(24.dp))
        Text(article.body, color = Color(0xFFE5EAF8), style = MaterialTheme.typography.bodyLarge, lineHeight = 30.sp)
        Spacer(Modifier.height(20.dp))
        Text("یادآوری: این متن آموزشی و خلاصه است؛ برای پژوهش تخصصی به منابع علمی ارجاعی مراجعه کن.", color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun AskScreen() {
    val context = LocalContext.current
    var question by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader("دستیار جست‌وجوی نجوم", "هرچه می‌خواهی بپرس", "برای بررسی تازه‌ترین اطلاعات، جست‌وجوی وب را باز کن")
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(16.dp)) {
                OutlinedTextField(question, { question = it; submitted = false }, Modifier.fillMaxWidth(), placeholder = { Text("مثلاً آیا در اروپا اقیانوس زیرسطحی وجود دارد؟") }, minLines = 3, shape = RoundedCornerShape(16.dp), colors = fieldColors(), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { if (question.isNotBlank()) openGoogle(context, question) }))
                Spacer(Modifier.height(12.dp))
                Button(onClick = { if (question.isNotBlank()) { submitted = true; openGoogle(context, question) } }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Night), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("جست‌وجو در گوگل", fontWeight = FontWeight.Bold)
                }
                if (submitted) Text("نتایج جست‌وجو در مرورگر باز شد. پاسخ هوشمندِ خلاصه‌شده نیازمند اتصال سرویس هوش مصنوعی و کلید API است.", color = Cyan, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp))
            }
        }
        Text("پرسش‌های پیشنهادی", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
        listOf("سیاه‌چاله چگونه تشکیل می‌شود؟", "کدام سیاره بیشترین قمر را دارد؟", "آیا انسان می‌تواند در مریخ زندگی کند؟").forEach { q ->
            Text("✦  $q", color = Muted, modifier = Modifier.fillMaxWidth().clickable { question = q }.padding(horizontal = 22.dp, vertical = 10.dp))
        }
    }
}

private fun openGoogle(context: android.content.Context, query: String) {
    val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode("نجوم فضا $query"))
    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
}

@Composable
fun SkyScreen() {
    var city by remember { mutableStateOf("باکو") }
    var refreshed by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(300_000); refreshed = System.currentTimeMillis() } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader("رصد آسمان", "آسمان بالای سر تو", "اطلاعات عمومی و آموزشی؛ برای موقعیت دقیق به داده‌های نجومی نیاز است")
        OutlinedTextField(city, { city = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp), label = { Text("شهر محل رصد") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = fieldColors())
        Card(Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("نمای روز و شب زمین", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(170.dp)) {
                        drawCircle(Brush.linearGradient(listOf(Color(0xFF1A9BE8), Color(0xFF10234C), Color(0xFF071329))))
                        drawArc(Color(0xFFFFD16E).copy(alpha = .65f), -90f, 180f, false, style = Stroke(10.dp.toPx()))
                        drawCircle(Color(0xFF68C8FF).copy(alpha = .25f), style = Stroke(1.dp.toPx()))
                    }
                    Text("🌍", fontSize = 64.sp)
                }
                Text("شهر انتخاب‌شده: $city", color = Color.White, fontWeight = FontWeight.Bold)
                Text("به‌روزرسانی نمای آموزشی: ${SimpleDateFormat("HH:mm", Locale("fa", "IR")).format(Date(refreshed))}", color = Muted, style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(8.dp))
                Text("برای نمایش دقیق محل خورشید و ماه در افق این شهر، زمان طلوع و غروب و سمت و ارتفاع اجرام، نسخه بعدی باید به مختصات جغرافیایی و محاسبات نجومی معتبر متصل شود.", color = Color(0xFFE0E7F7), style = MaterialTheme.typography.bodyMedium, lineHeight = 25.sp)
            }
        }
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF465577), focusedLabelColor = Cyan, unfocusedLabelColor = Muted, cursorColor = Gold)
