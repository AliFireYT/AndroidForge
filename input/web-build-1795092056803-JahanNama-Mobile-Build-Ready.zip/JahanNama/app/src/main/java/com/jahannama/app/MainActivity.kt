package com.jahannama.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

private val Night = Color(0xFF080D20)
private val Panel = Color(0xFF121B36)
private val Gold = Color(0xFFFFC766)
private val Cyan = Color(0xFF64D9FF)
private val Muted = Color(0xFFAAB6D3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,13,32)
        window.navigationBarColor = android.graphics.Color.rgb(8,13,32)
        setContent { JahanNamaApp() }
    }
}

data class SpaceFact(val title: String, val subtitle: String, val body: String, val emoji: String)
private val facts = listOf(
    SpaceFact("خورشید", "ستارهٔ مرکزی منظومه شمسی", "خورشید یک ستاره از ردهٔ کوتوله‌های زرد است. گرانش آن سیارات را در مدار نگه می‌دارد و انرژی نور و گرمایش سرچشمهٔ اصلی شرایط زیستی زمین است.", "☀️"),
    SpaceFact("زمین", "خانهٔ ما", "زمین سومین سیاره از خورشید است. حدود ۷۱ درصد سطح آن را آب پوشانده و جو آن از حیات شناخته‌شده پشتیبانی می‌کند.", "🌍"),
    SpaceFact("ماه", "قمر طبیعی زمین", "ماه تنها قمر طبیعی زمین است. گرانش ماه در جزر و مد اقیانوس‌ها نقش دارد و چرخهٔ فازهای آن تقریباً ۲۹٫۵ روز طول می‌کشد.", "🌕"),
    SpaceFact("مریخ", "سیارهٔ سرخ", "رنگ سرخ مریخ به اکسیدهای آهن موجود در خاک آن مربوط است. این سیاره آتشفشان‌های عظیم، دره‌های گسترده و نشانه‌هایی از آب مایع در گذشته دارد.", "🔴"),
    SpaceFact("مشتری", "غول گازی منظومه", "مشتری بزرگ‌ترین سیارهٔ منظومه شمسی است. لکهٔ سرخ بزرگ آن توفانی عظیم و پایدار است و این سیاره خانواده‌ای بزرگ از قمرها دارد.", "🪐"),
    SpaceFact("زحل", "سیارهٔ حلقه‌ها", "حلقه‌های زحل عمدتاً از تکه‌های یخ و سنگ تشکیل شده‌اند. زحل چگالی متوسطی کمتر از آب دارد.", "✨"),
    SpaceFact("راه شیری", "کهکشان خانهٔ ما", "راه شیری کهکشانی مارپیچی میله‌ای است و منظومه شمسی در یکی از بازوهای آن، به نام بازوی شکارچی، قرار دارد. مرکز کهکشان میزبان سیاه‌چاله‌ای کلان‌جرم است.", "🌌"),
    SpaceFact("سیاه‌چاله‌ها", "ناحیه‌ای با گرانش بسیار شدید", "سیاه‌چاله ناحیه‌ای از فضا-زمان است که پس از گذر از افق رویداد، حتی نور نیز نمی‌تواند از آن بگریزد.", "⚫")
)

@Composable fun JahanNamaApp() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Night, surface = Panel)) {
        Scaffold(containerColor = Night, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Muted) {
                val labels = listOf("آسمان", "دانشنامه", "پرسش", "درباره")
                val icons = listOf(Icons.Default.Public, Icons.Default.MenuBook, Icons.Default.Search, Icons.Default.Info)
                labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 11.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Color(0xFF293453), unselectedIconColor = Muted, unselectedTextColor = Muted)) }
            }
        }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when(tab) {
                    0 -> SkyScreen()
                    1 -> EncyclopediaScreen()
                    2 -> SearchScreen()
                    else -> AboutScreen()
                }
            }
        }
    }
}

@Composable private fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.End) {
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable private fun SkyScreen() {
    var selected by remember { mutableStateOf("زمین") }
    var speed by remember { mutableFloatStateOf(1f) }
    val rotation by rememberInfiniteTransition(label = "orbit").animateFloat(0f, 360f, infiniteRepeatable(tween((30000 / speed).toInt().coerceAtLeast(1000), easing = LinearEasing)), label = "rotation")
    var clock by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while(true) { delay(60_000); clock = Date() } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("جهان‌نما", "پنجره‌ای به شگفتی‌های کیهان")
        Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text("منظومهٔ شمسی", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("نمای آموزشیِ مداری · به‌روزرسانی نمایشی", color = Muted, fontSize = 11.sp)
            }
            Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(54.dp).clip(CircleShape))
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(330.dp).padding(horizontal = 12.dp).clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color(0xFF111C3B), Color(0xFF080D20))))) {
            Canvas(Modifier.fillMaxSize()) {
                val c = center
                val maxR = size.minDimension * .43f
                val orbitR = listOf(.13f,.20f,.27f,.34f,.41f)
                orbitR.forEach { r -> drawCircle(Color(0xFF52638A).copy(alpha=.55f), maxR*r/.43f, c, style=Stroke(1.dp.toPx())) }
                drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF2A8), Color(0xFFFFA52E), Color(0x66FF6B22)), c, 40.dp.toPx()), 25.dp.toPx(), c)
                val colors = listOf(Color(0xFF8CC7FF), Color(0xFF55A9FF), Color(0xFFDA8B63), Color(0xFFE7C58B), Color(0xFFB9A4FF))
                orbitR.forEachIndexed { i, r ->
                    val rad = Math.toRadians((rotation*(1.0/(i+1)) + i*74).toDouble())
                    val rr = maxR*r/.43f
                    val p = androidx.compose.ui.geometry.Offset(c.x + kotlin.math.cos(rad).toFloat()*rr, c.y + kotlin.math.sin(rad).toFloat()*rr)
                    drawCircle(colors[i], (5+i%3*2).dp.toPx(), p)
                    if(i==1) drawCircle(Color(0xFFB8E6FF).copy(alpha=.35f), 10.dp.toPx(), p)
                }
                for(i in 0..45) { val x=(i*73%997)/997f*size.width; val y=(i*137%991)/991f*size.height; drawCircle(Color.White.copy(alpha=.25f),1.dp.toPx(),androidx.compose.ui.geometry.Offset(x,y)) }
            }
            Text("☀", Modifier.align(Alignment.Center), color = Gold, fontSize = 35.sp)
            Text("مدارها شماتیک‌اند و مقیاس واقعی فاصله‌ها نیست", Modifier.align(Alignment.BottomCenter).padding(10.dp), color = Muted, fontSize = 10.sp)
        }
        Text("برای دیدن اطلاعات، یک جرم آسمانی را انتخاب کن", Modifier.fillMaxWidth().padding(16.dp), color = Muted, textAlign = TextAlign.End, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("خورشید","زمین","ماه","مریخ","مشتری","زحل").forEach { name ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if(selected==name) Color(0xFF34436A) else Panel).clickable { selected=name }.padding(vertical=12.dp), contentAlignment=Alignment.Center) { Text(name, color=if(selected==name) Gold else Color.White, fontSize=11.sp) }
            }
        }
        val fact = facts.firstOrNull { it.title==selected } ?: facts[0]
        Card(Modifier.fillMaxWidth().padding(16.dp), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), horizontalAlignment=Alignment.End) {
                Text("${fact.emoji}  ${fact.title}", color=Gold, fontWeight=FontWeight.Bold, fontSize=18.sp)
                Text(fact.subtitle, color=Muted, fontSize=12.sp)
                Spacer(Modifier.height(8.dp)); Text(fact.body, color=Color.White, textAlign=TextAlign.End, lineHeight=23.sp)
            }
        }
        Text("زمان دستگاه: ${SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale("fa")).format(clock)}", Modifier.fillMaxWidth().padding(16.dp), color=Muted, textAlign=TextAlign.Center, fontSize=11.sp)
        Text("سرعت حرکت نمایشی", Modifier.fillMaxWidth().padding(horizontal=20.dp), color=Muted, textAlign=TextAlign.End, fontSize=12.sp)
        Slider(value=speed, onValueChange={speed=it}, valueRange=.5f..3f, modifier=Modifier.padding(horizontal=18.dp), colors=SliderDefaults.colors(thumbColor=Gold, activeTrackColor=Gold))
    }
}

@Composable private fun EncyclopediaScreen() {
    var query by remember { mutableStateOf("") }
    val filtered = facts.filter { it.title.contains(query, true) || it.body.contains(query, true) }
    Column(Modifier.fillMaxSize()) {
        Header("دانشنامهٔ کیهان", "از همسایگان زمین تا دورترین شگفتی‌ها")
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp).clip(RoundedCornerShape(14.dp)).background(Panel).padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint=Muted)
            Spacer(Modifier.width(8.dp))
            BasicTextField(query, {query=it}, Modifier.weight(1f), textStyle= androidx.compose.ui.text.TextStyle(color=Color.White, textAlign=TextAlign.End), decorationBox={ inner -> if(query.isEmpty()) Text("جست‌وجو در دانشنامه...", color=Muted); inner() })
        }
        LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(filtered) { f -> Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp), modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), horizontalAlignment=Alignment.End) { Text("${f.emoji}  ${f.title}", color=Gold, fontWeight=FontWeight.Bold, fontSize=18.sp); Text(f.subtitle, color=Muted, fontSize=12.sp); Spacer(Modifier.height(6.dp)); Text(f.body, color=Color.White, textAlign=TextAlign.End, lineHeight=22.sp) } } }
        }
    }
}

@Composable private fun SearchScreen() {
    var question by remember { mutableStateOf("") }
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("دستیار نجوم", "سؤالت را بنویس و در وب جست‌وجو کن")
        Card(Modifier.fillMaxWidth().padding(16.dp), colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), horizontalAlignment=Alignment.End) {
                Text("چه چیزی دربارهٔ فضا می‌خواهی بدانی؟", color=Color.White, fontWeight=FontWeight.Bold, fontSize=17.sp)
                Spacer(Modifier.height(14.dp))
                BasicTextField(question, {question=it}, Modifier.fillMaxWidth().heightIn(min=110.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF202B49)).padding(12.dp), textStyle=androidx.compose.ui.text.TextStyle(color=Color.White, textAlign=TextAlign.End), decorationBox={ inner -> if(question.isEmpty()) Text("مثلاً: فاصله زمین تا خورشید چقدر است؟", color=Muted); inner() })
                Spacer(Modifier.height(14.dp))
                Button(onClick={ if(question.isNotBlank()) { val url="https://www.google.com/search?q="+Uri.encode("$question نجوم ناسا منابع علمی"); context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }, enabled=question.isNotBlank(), colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Night), modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Search, null); Spacer(Modifier.width(8.dp)); Text("جست‌وجو در گوگل") }
            }
        }
        Text("نسخهٔ فعلی جست‌وجو را در مرورگر باز می‌کند. برای پاسخ‌سازی هوشمند فارسی و نمایش منابع داخل خود برنامه، اتصال امن به سرویس هوش مصنوعی و کلید API لازم است.", Modifier.padding(horizontal=20.dp), color=Muted, textAlign=TextAlign.End, lineHeight=22.sp, fontSize=12.sp)
        Spacer(Modifier.height(20.dp))
        Text("پیشنهاد برای پرسیدن", Modifier.fillMaxWidth().padding(horizontal=20.dp), color=Gold, textAlign=TextAlign.End, fontWeight=FontWeight.Bold)
        listOf("سیاه‌چاله چگونه تشکیل می‌شود؟", "آیا در مریخ آب وجود دارد؟", "بزرگ‌ترین قمر منظومه شمسی کدام است؟").forEach { q -> Text("•  $q", Modifier.fillMaxWidth().clickable { question=q }.padding(horizontal=20.dp, vertical=9.dp), color=Color.White, textAlign=TextAlign.End) }
    }
}

@Composable private fun AboutScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp)); Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(132.dp).clip(RoundedCornerShape(28.dp)))
        Text("جهان‌نما", color=Color.White, fontSize=28.sp, fontWeight=FontWeight.Bold)
        Text("سفری علمی به جهان بی‌کران", color=Gold, fontSize=14.sp)
        Spacer(Modifier.height(24.dp))
        Card(Modifier.padding(18.dp), colors=CardDefaults.cardColors(containerColor=Panel)) { Column(Modifier.padding(18.dp), horizontalAlignment=Alignment.End) {
            Text("دربارهٔ این نسخه", color=Gold, fontWeight=FontWeight.Bold, fontSize=18.sp)
            Spacer(Modifier.height(8.dp))
            Text("این نسخه شامل نمای آموزشی منظومه شمسی، دانشنامهٔ اولیه و جست‌وجوی گوگل است. موقعیت‌های مداری فعلاً شماتیک و انیمیشنی هستند؛ برای موقعیت واقعی اجرام، محاسبات نجومی دقیق و دادهٔ مکانی شهر لازم است.", color=Color.White, textAlign=TextAlign.End, lineHeight=23.sp)
        } }
    }
}
